package com.ra2.jdbctemplate_h2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ra2A1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
